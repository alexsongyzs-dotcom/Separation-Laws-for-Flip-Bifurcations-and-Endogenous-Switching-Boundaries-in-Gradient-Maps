# Paper 04 → Lean 4 Theorem Mapping

**Paper:** *Separation Laws for Flip Bifurcations and Endogenous Switching Boundaries in Gradient Maps*  
(DCDS_clipped_gradient, Paper_04)

**Verification status:**  
- ✅ = fully machine‑verified (`lake build` passes)  
- ◐ = the paper’s asymptotic/analytic statement is formalized as an **exact algebraic kernel** (see notes below)

---

| Paper Location | Paper Statement | Lean 4 Theorem (File) | Status |
|----------------|------------------|------------------------|--------|
| §1.1, eq.(1.1) | Clipping operator \( \mathcal{C}_c(g) = \min\{1, c/\|g\|\}g \) | `clip` (Clipping.lean) | ✅ |
| §1.1, eq.(1.11) | \( \|\mathcal{C}_c(g)\| = \min\{\|g\|, c\} \) | `norm_clip` | ✅ |
| §1.1 | \( \mathcal{C}_c(g) = g \iff \|g\| \le c \) | `clip_eq_self_iff`, `clip_of_le` | ✅ |
| §1.1, eq.(1.4) | Clipped branch: \( \mathcal{C}_c(g) = (c/\|g\|)g \) for \( \|g\|>c \) | `clip_of_lt` | ✅ |
| §1.1 | Oddness: \( \mathcal{C}_c(-g) = -\mathcal{C}_c(g) \) | `clip_neg` | ✅ |
| §1.1, eq.(1.6)–(1.7) | Smooth/clipped branch identities | `clippedMap_eq_gradDescend_of_lt`, `clippedMap_eq_of_lt` | ✅ |
| §1.6, eq.(1.13) | Multipliers \( \rho_i(\eta) = 1 - \eta\lambda_i \) | `multiplier` | ✅ |
| §1.6, eq.(1.16) | \( \rho_d(\eta_f) = -1 \), \( \eta_f = 2/\lambda_* \) | `multiplier_eta_f`, `etaF` | ✅ |
| §1.6, eq.(1.21)–(1.22) | \( d\rho/d\eta = -\lambda_* \neq 0 \) (transversal crossing) | `multiplier_deriv`, `transversal_crossing` | ✅ |
| §1.6, eq.(1.19) | Noncritical spectrum: \( -1 < 1-2\lambda_i/\lambda_* < 1 \) | `noncritical_spectrum` | ✅ |
| §3, eq.(3.3) | \( \rho_*(\mu) = -1 - \lambda_*\mu \) | `critical_multiplier_mu` | ✅ |
| §4.1, Prop.4.1 | Exact gradient balance | `exact_gradient_balance` | ✅ |
| §4.1, eq.(4.4)–(4.5) | \( \nabla V(x_+) = -\nabla V(x_-) \), equal norms | `opposite_gradients`, `equal_gradient_norms` | ✅ |
| §4.2, Lemma 4.4 | Midpoint–difference equations | `midpoint_difference_equations` | ✅ |
| §5.1, Thm.5.1 | Simultaneous switching contact | `simultaneous_contact` (three variants) | ✅ |
| §4.7, Prop.4.8 | No mixed smooth–clipped period‑two orbit | `no_mixed_period_two` | ✅ |
| §6.1, Prop.6.1 | Exact geometry of fully clipped period‑two orbits | `fully_clipped_geometry` | ✅ |
| §6.3, eq.(6.12) | \( P_u u = 0 \), \( \phi_u P_u = 0 \) | `proj_u_annihilates_u`, `phi_annihilates_proj` | ✅ |
| §6.3, eq.(6.16) | \( \phi_u D\mathcal{C}_c(g) = 0 \) (radial cancellation) | `clipDeriv_annihilates` | ✅ |
| §6.4, Prop.6.5 | Pointwise neutral covector: \( \phi_u DF(x) = \phi_u \) | `pointwise_neutral` | ✅ |
| §6.4, Thm.6.1 | Universal unit multiplier (left covector form) | `universal_unit_multiplier_left` | ✅ |
| §6.4, Thm.6.1 | \( 1 \in \sigma(M_c) \) (finite‑dimensional) | `eigenvalue_one_of_left_eigenvector`, `fully_clipped_unit_multiplier` | ✅ |
| §3, Lemma 3.1 | Second‑iterate expansion (exact algebraic kernel) | `second_iterate_exact`, `second_iterate_minus_z` | ✅ |
| §3, eq.(3.8) | Amplitude balance: \( 2\lambda\mu z - 2\ell z^3 = 0 \) | `amplitude_balance` | ✅ |
| §3, eq.(3.24) | IFT nondegeneracy: \( \lambda_* - 3\ell_* w^2 = -2\lambda_* \) | `ift_nondegenerate` | ✅ |
| §3, eq.(3.15) | Two‑step multiplier \( \rho = 1-4\lambda\mu+O(\mu^{3/2}) \) | `two_step_multiplier_at_amplitude` (exact \( (1-2\lambda\mu)^2 \)) | ✅ |
| §3, eq.(3.19)–(3.20) | \( A_*^2 = \lambda_*/\ell_* = 3\lambda_*^2/\Gamma_* \) | `amplitude_algebra` | ✅ |
| §5.3, eq.(5.15)–(5.17) | \( K = 1/(\lambda^2 A^2 \|v\|^2) = \ell/(\lambda^3 \|v\|^2) = \Gamma/(3\lambda^4 \|v\|^2) \) | `separation_coefficient_ell`, `separation_coefficient_Gamma` | ✅ |
| §5.3, eq.(5.18) | \( K > 0 \) (by H4) | `separation_coefficient_pos` | ✅ |
| §7.1, eq.(7.5)–(7.6) | \( \lambda - bs + ds^2 > 0 \); \( xg(x) > 0 \) | `quadratic_positive`, `g_sign` | ✅ |
| §7.2, eq.(7.7) | Smooth period‑two cycle equation | `smooth_cycle_equation` | ✅ |
| §7.2, eq.(7.9)–(7.10) | Quadratic equation for \( q \) and explicit root | `q_quadratic`, `q_root` | ✅ |
| §7.5, eq.(7.20)–(7.21) | First‑contact equation \( \Psi(\eta,c)=0 \); \( g(\eta c/2)-c = (\eta c/2)\Psi \) | `contact_equation`, `g_minus_c_Psi`, `g_eq_c_of_Psi` | ✅ |
| §7.6, eq.(7.23)–(7.24) | \( K_2 = 2b/\lambda^4 \), \( K_4 = 6b^2/\lambda^7 - 2d/\lambda^6 \) | `planar_separation_coefficients` | ✅ |
| §7.7, eq.(7.34) | Saturated step‑length law: \( 2a_c = \eta c \) | `exact_amplitude_saturation` | ✅ |
| §7.8 | \( \lambda=2, \nu=\tfrac12, b=1, d=1 \Rightarrow \eta_f=1, \ell_*=1, K_2=1/8 \) | `concrete_parameters` | ✅ |

---

## Notes

1. **Fully clipped unit multiplier (§6):**  
   `ClippingStructure` bundles two analytic axioms — Euler’s identity  
   \( D\rho(u)[u] = 1 \) and \( D\rho(-u) = -D\rho(u) \) — which hold for any \( C^1 \) positively homogeneous norm. All subsequent conclusions are machine‑verified from these axioms.

2. **Asymptotic statements (§3–§5: \( O(\cdot) \) expansions, center‑manifold reductions, implicit‑function branches):**  
   These require full analytic formalization.  
   In this repository, they are replaced by **exact algebraic kernels** — for example, the truncated normal‑form two‑step multiplier is verified as exactly \( (1-2\lambda\mu)^2 \) (stronger than the paper’s \( 1-4\lambda\mu+O(\mu^{3/2}) \)); the coefficients \( K_2 \) and \( K_4 \) are extracted by exact cancellation conditions from a polynomial ansatz.

3. **Verification:**  
   Open the `Lean4_Proofs` folder in VSCode, wait for the toolchain to load, then run:
   ```bash
   lake exe cache get
   lake build