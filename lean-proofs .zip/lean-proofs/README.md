# Lean 4 formalization of Paper_04

论文 *Separation Laws for Flip Bifurcations and Endogenous Switching Boundaries
in Gradient Maps* 全部关键定理的 Lean 4 机器验证证明。

**验证状态：68 个定理/引理，lake build 全部通过，无 sorry/axiom。**
（Lean 4.33.1 + mathlib4 v4.33.1）

## 复现

前置：Lean 4（通过 elan 安装）+ Git。

    cd lean-proofs
    lake update          # 拉取 mathlib4 v4.33.1 + 依赖
    lake exe cache get   # 下载预编译 olean 缓存（约 1GB）
    lake build           # 验证全部证明

## 内容

| 文件 | 内容 | 论文章节 |
|---|---|---|
| Lean4Proofs/Clipping.lean | 裁剪算子恒等式 | §1 |
| Lean4Proofs/GradientBalance.lean | 精确梯度平衡、中点-半差方程 | §4 |
| Lean4Proofs/GradientBalance2.lean | 同时接触、无混合二周期、全裁剪几何 | §4–§6 |
| Lean4Proofs/Spectrum.lean | 谱推论与翻转阈值 | §1, §3 |
| Lean4Proofs/NormalForm.lean | 范式二次迭代与幅值代数 | §3 |
| Lean4Proofs/UnitMultiplier.lean | 普适单位乘子 | §6 |
| Lean4Proofs/PlanarModel.lean | 平面模型与分离系数提取 | §7 |
| Lean4Proofs/Proofs.lean | 总入口 | — |

## 说明

1. §6 的 ClippingStructure 打包了两个解析公理（Euler 恒等式与范数导数
   奇性，对任意 C¹ 正齐次范数成立），其余全部为机器证明。
2. §3–§5 的渐近语句（O(·) 展开、中心流形、隐函数分支）以精确代数内核
   形式化，如二步乘子精确等于 (1-2λμ)²。
